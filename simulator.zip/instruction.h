#ifndef _INSTRUCTION_H_
#define _INSTRUCTION_H_

extern void decode(unsigned);
extern int signExtend8(int);
extern int signExtend16(int);
extern int signExtend26(int);

#endif